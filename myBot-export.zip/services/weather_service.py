import os
import requests
import logging

WEATHER_API_KEY = os.environ.get("OPENWEATHER_API_KEY")

def get_weather(location="current location"):
    """Get weather information using OpenWeatherMap API"""
    if not WEATHER_API_KEY:
        return "I need a weather API key to get weather information. Please check your configuration."
    
    try:
        # If location is "current location", use a default city
        if location.lower() in ["current location", "here", "my location"]:
            location = "New York"  # Default location
        
        # Get current weather
        url = f"http://api.openweathermap.org/data/2.5/weather"
        params = {
            'q': location,
            'appid': WEATHER_API_KEY,
            'units': 'metric'
        }
        
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        # Extract relevant information
        city = data['name']
        country = data['sys']['country']
        temp = data['main']['temp']
        temp_fahrenheit = (temp * 9/5) + 32
        feels_like = data['main']['feels_like']
        feels_like_fahrenheit = (feels_like * 9/5) + 32
        humidity = data['main']['humidity']
        description = data['weather'][0]['description'].title()
        wind_speed = data['wind']['speed']
        
        # Format the response
        weather_info = f"🌤️ Weather in {city}, {country}:\n"
        weather_info += f"Temperature: {temp:.1f}°C ({temp_fahrenheit:.1f}°F)\n"
        weather_info += f"Feels like: {feels_like:.1f}°C ({feels_like_fahrenheit:.1f}°F)\n"
        weather_info += f"Conditions: {description}\n"
        weather_info += f"Humidity: {humidity}%\n"
        weather_info += f"Wind Speed: {wind_speed} m/s"
        
        return weather_info
        
    except requests.exceptions.RequestException as e:
        logging.error(f"Weather API request error: {str(e)}")
        return "Sorry, I couldn't get the weather information right now. Please check your internet connection and try again."
    except KeyError as e:
        logging.error(f"Weather API data parsing error: {str(e)}")
        return f"Sorry, I couldn't find weather information for '{location}'. Please check the location name and try again."
    except Exception as e:
        logging.error(f"Weather service error: {str(e)}")
        return "Sorry, I encountered an error getting the weather information. Please try again later."

def get_weather_forecast(location="current location", days=3):
    """Get weather forecast for the next few days"""
    if not WEATHER_API_KEY:
        return "I need a weather API key to get weather forecasts. Please check your configuration."
    
    try:
        if location.lower() in ["current location", "here", "my location"]:
            location = "New York"  # Default location
        
        # Get forecast
        url = f"http://api.openweathermap.org/data/2.5/forecast"
        params = {
            'q': location,
            'appid': WEATHER_API_KEY,
            'units': 'metric',
            'cnt': days * 8  # 8 forecasts per day (every 3 hours)
        }
        
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        city = data['city']['name']
        country = data['city']['country']
        
        forecast_info = f"🌦️ {days}-day forecast for {city}, {country}:\n\n"
        
        # Group forecasts by day
        current_date = None
        for item in data['list'][:days*8]:
            date = item['dt_txt'].split(' ')[0]
            time = item['dt_txt'].split(' ')[1]
            
            if date != current_date:
                current_date = date
                forecast_info += f"📅 {date}:\n"
            
            temp = item['main']['temp']
            temp_fahrenheit = (temp * 9/5) + 32
            description = item['weather'][0]['description'].title()
            
            forecast_info += f"  {time}: {temp:.1f}°C ({temp_fahrenheit:.1f}°F) - {description}\n"
        
        return forecast_info
        
    except Exception as e:
        logging.error(f"Weather forecast error: {str(e)}")
        return "Sorry, I couldn't get the weather forecast right now. Please try again later."
