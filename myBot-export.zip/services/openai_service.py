import os
from openai import OpenAI
import logging

# the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
# do not change this unless explicitly requested by the user

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")

def get_ai_response(message):
    """Get response from OpenAI GPT"""
    if not OPENAI_API_KEY:
        return "I'm sorry, but I need an OpenAI API key to respond to your message. Please check your configuration."
    
    try:
        client = OpenAI(api_key=OPENAI_API_KEY)
        
        # Create a warm, witty AI personality
        system_prompt = """You are myBot, a warm and witty personal AI assistant. You're helpful, friendly, and have a subtle sense of humor. 
        You help users with various tasks including managing their to-do lists, getting weather updates, searching the web, and general conversation.
        Keep your responses concise but personable. Use appropriate emojis occasionally to add warmth to your responses.
        If someone asks about your capabilities, mention that you can help with tasks, weather, web searches, reminders, and general conversation."""
        
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": message}
            ],
            max_tokens=500,
            temperature=0.7
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        logging.error(f"OpenAI API error: {str(e)}")
        return "I'm having trouble connecting to my AI brain right now. Could you try again in a moment? 🤖"

def get_command_classification(message):
    """Use AI to classify the user's intent"""
    if not OPENAI_API_KEY:
        return "general"
    
    try:
        client = OpenAI(api_key=OPENAI_API_KEY)
        
        classification_prompt = f"""Classify the following user message into one of these categories:
        - todo: related to task management, adding tasks, completing tasks, or viewing tasks
        - weather: asking about weather, temperature, or forecast
        - search: requesting to search for information, look something up, or find information
        - reminder: setting reminders or scheduling something
        - time: asking about current time or date
        - general: general conversation or questions
        
        User message: "{message}"
        
        Respond with only the category name."""
        
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": classification_prompt}],
            max_tokens=10,
            temperature=0.1
        )
        
        return response.choices[0].message.content.strip().lower()
        
    except Exception as e:
        logging.error(f"Classification error: {str(e)}")
        return "general"
