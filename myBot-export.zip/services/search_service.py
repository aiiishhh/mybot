import os
import requests
import logging

SEARCH_API_KEY = os.environ.get("SERPAPI_API_KEY")

def web_search(query):
    """Perform web search using SerpAPI"""
    if not SEARCH_API_KEY:
        return "I need a search API key to perform web searches. Please check your configuration."
    
    try:
        # Use SerpAPI for Google search
        url = "https://serpapi.com/search"
        params = {
            'q': query,
            'api_key': SEARCH_API_KEY,
            'engine': 'google',
            'num': 5  # Get top 5 results
        }
        
        response = requests.get(url, params=params, timeout=15)
        response.raise_for_status()
        
        data = response.json()
        
        if 'organic_results' not in data:
            return f"No search results found for '{query}'"
        
        # Format search results
        search_results = f"🔍 Search results for '{query}':\n\n"
        
        for i, result in enumerate(data['organic_results'][:5], 1):
            title = result.get('title', 'No title')
            link = result.get('link', '')
            snippet = result.get('snippet', 'No description available')
            
            search_results += f"{i}. **{title}**\n"
            search_results += f"   {snippet}\n"
            search_results += f"   🔗 {link}\n\n"
        
        return search_results
        
    except requests.exceptions.RequestException as e:
        logging.error(f"Search API request error: {str(e)}")
        return "Sorry, I couldn't perform the search right now. Please check your internet connection and try again."
    except Exception as e:
        logging.error(f"Search service error: {str(e)}")
        return "Sorry, I encountered an error while searching. Please try again later."

def search_news(query):
    """Search for news articles"""
    if not SEARCH_API_KEY:
        return "I need a search API key to search for news. Please check your configuration."
    
    try:
        url = "https://serpapi.com/search"
        params = {
            'q': query,
            'api_key': SEARCH_API_KEY,
            'engine': 'google',
            'tbm': 'nws',  # News search
            'num': 5
        }
        
        response = requests.get(url, params=params, timeout=15)
        response.raise_for_status()
        
        data = response.json()
        
        if 'news_results' not in data:
            return f"No news results found for '{query}'"
        
        news_results = f"📰 Latest news for '{query}':\n\n"
        
        for i, result in enumerate(data['news_results'][:5], 1):
            title = result.get('title', 'No title')
            link = result.get('link', '')
            source = result.get('source', 'Unknown source')
            date = result.get('date', '')
            
            news_results += f"{i}. **{title}**\n"
            news_results += f"   Source: {source}"
            if date:
                news_results += f" | {date}"
            news_results += f"\n   🔗 {link}\n\n"
        
        return news_results
        
    except Exception as e:
        logging.error(f"News search error: {str(e)}")
        return "Sorry, I couldn't search for news right now. Please try again later."

def quick_search(query):
    """Perform a quick search and return a summary"""
    if not SEARCH_API_KEY:
        return "I need a search API key to perform searches. Please check your configuration."
    
    try:
        url = "https://serpapi.com/search"
        params = {
            'q': query,
            'api_key': SEARCH_API_KEY,
            'engine': 'google',
            'num': 3
        }
        
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        # Check for knowledge graph (instant answer)
        if 'knowledge_graph' in data:
            kg = data['knowledge_graph']
            result = f"🔍 Quick answer for '{query}':\n\n"
            if 'title' in kg:
                result += f"**{kg['title']}**\n"
            if 'description' in kg:
                result += f"{kg['description']}\n"
            return result
        
        # Check for answer box
        if 'answer_box' in data:
            ab = data['answer_box']
            result = f"🔍 Quick answer for '{query}':\n\n"
            if 'answer' in ab:
                result += f"{ab['answer']}\n"
            elif 'snippet' in ab:
                result += f"{ab['snippet']}\n"
            return result
        
        # Fallback to first search result
        if 'organic_results' in data and data['organic_results']:
            first_result = data['organic_results'][0]
            result = f"🔍 Top result for '{query}':\n\n"
            result += f"**{first_result.get('title', 'No title')}**\n"
            result += f"{first_result.get('snippet', 'No description available')}\n"
            result += f"🔗 {first_result.get('link', '')}"
            return result
        
        return f"No quick answer found for '{query}'. Try a more specific search."
        
    except Exception as e:
        logging.error(f"Quick search error: {str(e)}")
        return "Sorry, I couldn't perform the quick search right now. Please try again later."
