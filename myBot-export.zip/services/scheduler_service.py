import os
import logging
from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.date import DateTrigger
from models import Reminder

# Initialize scheduler
scheduler = BackgroundScheduler()
scheduler.start()

def schedule_reminder(reminder):
    """Schedule a reminder notification"""
    try:
        def reminder_callback():
            """Callback function for when reminder triggers"""
            logging.info(f"Reminder triggered: {reminder.title}")
            # In a real app, this would send a notification
            # For now, we'll just log it and mark as completed
            reminder.completed = True
            from app import db
            db.session.commit()
        
        # Schedule the reminder
        scheduler.add_job(
            func=reminder_callback,
            trigger=DateTrigger(run_date=reminder.reminder_time),
            id=f"reminder_{reminder.id}",
            name=f"Reminder: {reminder.title}",
            misfire_grace_time=3600  # 1 hour grace time
        )
        
        logging.info(f"Scheduled reminder '{reminder.title}' for {reminder.reminder_time}")
        return True
        
    except Exception as e:
        logging.error(f"Error scheduling reminder: {str(e)}")
        return False

def cancel_reminder(reminder_id):
    """Cancel a scheduled reminder"""
    try:
        scheduler.remove_job(f"reminder_{reminder_id}")
        logging.info(f"Cancelled reminder {reminder_id}")
        return True
    except Exception as e:
        logging.error(f"Error cancelling reminder: {str(e)}")
        return False

def get_scheduled_reminders():
    """Get all scheduled reminders"""
    try:
        jobs = scheduler.get_jobs()
        reminders = []
        for job in jobs:
            if job.id.startswith('reminder_'):
                reminders.append({
                    'id': job.id,
                    'name': job.name,
                    'next_run': job.next_run_time
                })
        return reminders
    except Exception as e:
        logging.error(f"Error getting scheduled reminders: {str(e)}")
        return []

def parse_reminder_time(time_string):
    """Parse natural language time into datetime object"""
    now = datetime.now()
    time_string = time_string.lower().strip()
    
    try:
        # Handle relative times
        if 'in' in time_string:
            if 'minute' in time_string:
                minutes = int(''.join(filter(str.isdigit, time_string)))
                return now + timedelta(minutes=minutes)
            elif 'hour' in time_string:
                hours = int(''.join(filter(str.isdigit, time_string)))
                return now + timedelta(hours=hours)
            elif 'day' in time_string:
                days = int(''.join(filter(str.isdigit, time_string)))
                return now + timedelta(days=days)
        
        # Handle specific times
        elif 'tomorrow' in time_string:
            if 'at' in time_string:
                time_part = time_string.split('at')[1].strip()
                hour = parse_hour(time_part)
                if hour is not None:
                    return now.replace(hour=hour, minute=0, second=0, microsecond=0) + timedelta(days=1)
            return now.replace(hour=9, minute=0, second=0, microsecond=0) + timedelta(days=1)
        
        elif 'today' in time_string:
            if 'at' in time_string:
                time_part = time_string.split('at')[1].strip()
                hour = parse_hour(time_part)
                if hour is not None:
                    reminder_time = now.replace(hour=hour, minute=0, second=0, microsecond=0)
                    if reminder_time <= now:
                        reminder_time += timedelta(days=1)
                    return reminder_time
        
        # Handle specific times like "at 3pm", "at 15:30"
        elif 'at' in time_string:
            time_part = time_string.split('at')[1].strip()
            hour = parse_hour(time_part)
            if hour is not None:
                reminder_time = now.replace(hour=hour, minute=0, second=0, microsecond=0)
                if reminder_time <= now:
                    reminder_time += timedelta(days=1)
                return reminder_time
        
        return None
        
    except Exception as e:
        logging.error(f"Error parsing reminder time '{time_string}': {str(e)}")
        return None

def parse_hour(time_string):
    """Parse hour from time string"""
    try:
        time_string = time_string.lower().strip()
        
        # Handle AM/PM format
        if 'pm' in time_string:
            hour = int(''.join(filter(str.isdigit, time_string)))
            if hour != 12:
                hour += 12
            return hour
        elif 'am' in time_string:
            hour = int(''.join(filter(str.isdigit, time_string)))
            if hour == 12:
                hour = 0
            return hour
        
        # Handle 24-hour format
        elif ':' in time_string:
            parts = time_string.split(':')
            hour = int(parts[0])
            return hour if 0 <= hour <= 23 else None
        
        # Handle simple hour
        else:
            hour = int(''.join(filter(str.isdigit, time_string)))
            return hour if 0 <= hour <= 23 else None
            
    except Exception:
        return None

# Cleanup function to remove completed reminders
def cleanup_old_reminders():
    """Remove old completed reminders"""
    try:
        from app import db
        cutoff_date = datetime.now() - timedelta(days=7)  # Remove reminders older than 7 days
        old_reminders = Reminder.query.filter(
            Reminder.completed == True,
            Reminder.created_at < cutoff_date
        ).all()
        
        for reminder in old_reminders:
            db.session.delete(reminder)
        
        db.session.commit()
        logging.info(f"Cleaned up {len(old_reminders)} old reminders")
        
    except Exception as e:
        logging.error(f"Error cleaning up old reminders: {str(e)}")

# Schedule cleanup to run daily
scheduler.add_job(
    func=cleanup_old_reminders,
    trigger='cron',
    hour=2,  # Run at 2 AM
    minute=0,
    id='cleanup_reminders'
)
