# myBot - Personal AI Assistant

## Overview

This is a Flask-based personal AI assistant application that provides conversational AI capabilities with specialized features for task management, weather information, web search, and reminders. The application uses OpenAI's GPT-4o model for natural language processing and includes a modern web interface built with Bootstrap.

## System Architecture

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Database**: SQLAlchemy ORM with SQLite as default (configurable to PostgreSQL via DATABASE_URL)
- **AI Service**: OpenAI GPT-4o API integration
- **External APIs**: 
  - OpenWeatherMap for weather data
  - SerpAPI for web search functionality
- **Task Scheduling**: APScheduler for reminder management

### Frontend Architecture
- **UI Framework**: Bootstrap 5 with dark theme
- **Icons**: Feather Icons
- **JavaScript**: Vanilla JS for chat functionality
- **Real-time Communication**: AJAX requests to Flask backend

### Database Schema
The application uses three main models:
- **TodoItem**: Task management with completion tracking
- **ChatMessage**: Conversation history with message type classification
- **Reminder**: Scheduled notifications with timestamp management

## Key Components

### Core Services
1. **OpenAI Service** (`services/openai_service.py`)
   - Handles GPT-4o API communication
   - Implements personality customization for the assistant
   - Provides message classification capabilities

2. **Weather Service** (`services/weather_service.py`)
   - Integrates with OpenWeatherMap API
   - Provides current weather information for specified locations
   - Supports both Celsius and Fahrenheit temperature formats

3. **Search Service** (`services/search_service.py`)
   - Uses SerpAPI for Google search integration
   - Returns formatted search results with titles, snippets, and links

4. **Scheduler Service** (`services/scheduler_service.py`)
   - Manages reminder scheduling using APScheduler
   - Handles background task execution for notifications

### Models Layer
- Uses SQLAlchemy with DeclarativeBase for modern ORM patterns
- Implements proper datetime handling with UTC timestamps
- Includes relationship tracking between messages and their types

### Routes Layer
- Centralized message processing with type classification
- RESTful API endpoints for chat functionality
- Error handling and logging throughout the request pipeline

## Data Flow

1. **User Input**: Messages are received through the web interface
2. **Message Classification**: AI determines the intent (chat, todo, weather, search, reminder)
3. **Service Routing**: Based on classification, appropriate service handles the request
4. **Database Storage**: All interactions are logged to the database
5. **Response Generation**: Formatted responses are returned to the frontend
6. **UI Update**: JavaScript updates the chat interface with new messages

## External Dependencies

### Required Environment Variables
- `OPENAI_API_KEY`: For AI response generation
- `OPENWEATHER_API_KEY`: For weather information
- `SERPAPI_API_KEY`: For web search functionality
- `DATABASE_URL`: Database connection string (optional, defaults to SQLite)
- `SESSION_SECRET`: Flask session security key

### API Services
- **OpenAI GPT-4o**: Primary AI model for conversational responses
- **OpenWeatherMap**: Weather data provider
- **SerpAPI**: Google search results provider

### Python Dependencies
- Flask ecosystem (Flask, Flask-SQLAlchemy)
- OpenAI Python client
- APScheduler for background tasks
- Requests for HTTP client functionality

## Deployment Strategy

### Development Environment
- Uses SQLite for local development
- Debug mode enabled by default
- Hot reload capabilities through Flask development server

### Production Considerations
- Configurable database URL for PostgreSQL migration
- ProxyFix middleware for reverse proxy compatibility
- Connection pooling and health checks configured
- Logging system in place for monitoring

### Environment Configuration
- Environment-based configuration for all external services
- Graceful degradation when API keys are missing
- Default fallbacks for development workflow

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- June 30, 2025. Initial setup