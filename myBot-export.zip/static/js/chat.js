// Chat functionality for myBot
class ChatBot {
    constructor() {
        this.chatMessages = document.getElementById('chatMessages');
        this.messageInput = document.getElementById('messageInput');
        this.chatForm = document.getElementById('chatForm');
        this.sendButton = document.getElementById('sendButton');
        this.quickTodoForm = document.getElementById('quickTodoForm');
        this.quickTodoInput = document.getElementById('quickTodoInput');
        this.recentActions = document.getElementById('recentActions');
        
        this.initializeEventListeners();
        this.messageInput.focus();
    }
    
    initializeEventListeners() {
        // Main chat form
        this.chatForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.sendMessage();
        });
        
        // Quick todo form
        this.quickTodoForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const task = this.quickTodoInput.value.trim();
            if (task) {
                this.sendMessage(`Add task: ${task}`);
                this.quickTodoInput.value = '';
            }
        });
        
        // Auto-resize input
        this.messageInput.addEventListener('input', () => {
            this.messageInput.style.height = 'auto';
            this.messageInput.style.height = this.messageInput.scrollHeight + 'px';
        });
        
        // Enter key handling
        this.messageInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
    }
    
    async sendMessage(message = null) {
        const messageText = message || this.messageInput.value.trim();
        if (!messageText) return;
        
        // Clear input if using main form
        if (!message) {
            this.messageInput.value = '';
            this.messageInput.style.height = 'auto';
        }
        
        // Add user message to chat
        this.addMessage(messageText, 'user');
        
        // Show typing indicator
        this.showTypingIndicator();
        
        // Disable send button
        this.sendButton.disabled = true;
        
        try {
            // Send to backend
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: messageText })
            });
            
            const data = await response.json();
            
            // Remove typing indicator
            this.hideTypingIndicator();
            
            if (response.ok) {
                // Add bot response
                this.addMessage(data.response, 'bot', data.type);
                
                // Add to recent actions
                this.addRecentAction(data.type || 'chat', messageText);
            } else {
                // Handle error
                this.addMessage(data.error || 'Sorry, something went wrong. Please try again.', 'bot', 'error');
            }
            
        } catch (error) {
            console.error('Chat error:', error);
            this.hideTypingIndicator();
            this.addMessage('Sorry, I\'m having trouble connecting. Please check your internet connection and try again.', 'bot', 'error');
        } finally {
            // Re-enable send button
            this.sendButton.disabled = false;
            this.messageInput.focus();
        }
    }
    
    addMessage(text, sender, type = 'chat') {
        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${sender}-message`;
        
        if (type && type !== 'chat') {
            messageDiv.classList.add(`message-type-${type}`);
        }
        
        const avatar = document.createElement('div');
        avatar.className = 'message-avatar';
        
        if (sender === 'bot') {
            avatar.innerHTML = '<i data-feather="cpu"></i>';
        } else {
            avatar.innerHTML = '<i data-feather="user"></i>';
        }
        
        const content = document.createElement('div');
        content.className = 'message-content';
        
        const messageText = document.createElement('div');
        messageText.className = 'message-text';
        messageText.innerHTML = this.formatMessage(text);
        
        const messageTime = document.createElement('div');
        messageTime.className = 'message-time';
        messageTime.innerHTML = `<small class="text-muted">${this.getCurrentTime()}</small>`;
        
        content.appendChild(messageText);
        content.appendChild(messageTime);
        
        messageDiv.appendChild(avatar);
        messageDiv.appendChild(content);
        
        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
        
        // Replace feather icons
        feather.replace();
    }
    
    formatMessage(text) {
        // Convert line breaks to <br>
        let formatted = text.replace(/\n/g, '<br>');
        
        // Convert URLs to clickable links
        formatted = formatted.replace(
            /(https?:\/\/[^\s]+)/g, 
            '<a href="$1" target="_blank">$1</a>'
        );
        
        // Convert markdown-style bold text
        formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        
        // Convert bullet points
        formatted = formatted.replace(/^• (.+)$/gm, '<li>$1</li>');
        formatted = formatted.replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>');
        
        return formatted;
    }
    
    showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'chat-message bot-message typing-message';
        typingDiv.id = 'typingIndicator';
        
        const avatar = document.createElement('div');
        avatar.className = 'message-avatar';
        avatar.innerHTML = '<i data-feather="cpu"></i>';
        
        const content = document.createElement('div');
        content.className = 'message-content';
        
        const typingIndicator = document.createElement('div');
        typingIndicator.className = 'typing-indicator';
        typingIndicator.innerHTML = `
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        `;
        
        content.appendChild(typingIndicator);
        typingDiv.appendChild(avatar);
        typingDiv.appendChild(content);
        
        this.chatMessages.appendChild(typingDiv);
        this.scrollToBottom();
        
        // Replace feather icons
        feather.replace();
    }
    
    hideTypingIndicator() {
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }
    
    addRecentAction(type, message) {
        const actionDiv = document.createElement('div');
        actionDiv.className = 'mb-2';
        
        let icon = 'message-circle';
        let actionText = 'General chat';
        
        switch (type) {
            case 'todo':
                icon = 'list';
                actionText = 'Task management';
                break;
            case 'weather':
                icon = 'cloud';
                actionText = 'Weather query';
                break;
            case 'search':
                icon = 'search';
                actionText = 'Web search';
                break;
            case 'reminder':
                icon = 'bell';
                actionText = 'Reminder set';
                break;
            case 'time':
                icon = 'clock';
                actionText = 'Time query';
                break;
        }
        
        actionDiv.innerHTML = `
            <i data-feather="${icon}" class="me-1"></i>
            ${actionText}
        `;
        
        // Add to top of recent actions
        this.recentActions.insertBefore(actionDiv, this.recentActions.firstChild);
        
        // Keep only last 5 actions
        const actions = this.recentActions.children;
        while (actions.length > 5) {
            this.recentActions.removeChild(actions[actions.length - 1]);
        }
        
        // Replace feather icons
        feather.replace();
    }
    
    scrollToBottom() {
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    }
    
    getCurrentTime() {
        return new Date().toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }
}

// Quick action function
function quickAction(message) {
    if (window.chatBot) {
        window.chatBot.sendMessage(message);
    }
}

// Clear chat function
function clearChat() {
    if (confirm('Are you sure you want to clear the chat history?')) {
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.innerHTML = `
            <div class="chat-message bot-message">
                <div class="message-avatar">
                    <i data-feather="cpu"></i>
                </div>
                <div class="message-content">
                    <div class="message-text">
                        👋 Hello! I'm myBot, your personal AI assistant. I can help you with:
                        <ul class="mt-2 mb-0">
                            <li>Managing your to-do list</li>
                            <li>Getting weather updates</li>
                            <li>Searching the web</li>
                            <li>Setting reminders</li>
                            <li>General conversation and questions</li>
                        </ul>
                        Try saying something like "Add task: buy groceries" or "What's the weather like?"
                    </div>
                    <div class="message-time">
                        <small class="text-muted">Just now</small>
                    </div>
                </div>
            </div>
        `;
        
        // Clear recent actions
        const recentActions = document.getElementById('recentActions');
        recentActions.innerHTML = `
            <div class="mb-2">
                <i data-feather="message-circle" class="me-1"></i>
                Welcome message sent
            </div>
        `;
        
        // Replace feather icons
        feather.replace();
    }
}

// Initialize chat bot when page loads
document.addEventListener('DOMContentLoaded', function() {
    window.chatBot = new ChatBot();
});

// Handle page visibility changes
document.addEventListener('visibilitychange', function() {
    if (!document.hidden && window.chatBot) {
        window.chatBot.messageInput.focus();
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + K to focus message input
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        if (window.chatBot) {
            window.chatBot.messageInput.focus();
        }
    }
    
    // Escape to clear current input
    if (e.key === 'Escape') {
        if (window.chatBot) {
            window.chatBot.messageInput.value = '';
            window.chatBot.messageInput.style.height = 'auto';
        }
    }
});

// Auto-save draft functionality
let draftSaveTimeout;
document.addEventListener('DOMContentLoaded', function() {
    const messageInput = document.getElementById('messageInput');
    
    // Load draft on page load
    const savedDraft = localStorage.getItem('chatDraft');
    if (savedDraft) {
        messageInput.value = savedDraft;
    }
    
    // Save draft as user types
    messageInput.addEventListener('input', function() {
        clearTimeout(draftSaveTimeout);
        draftSaveTimeout = setTimeout(() => {
            localStorage.setItem('chatDraft', messageInput.value);
        }, 1000);
    });
    
    // Clear draft when message is sent
    document.getElementById('chatForm').addEventListener('submit', function() {
        localStorage.removeItem('chatDraft');
    });
});
