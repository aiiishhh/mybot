from flask import render_template, request, jsonify, redirect, url_for
from app import app, db
from models import TodoItem, ChatMessage, Reminder
from services.openai_service import get_ai_response
from services.weather_service import get_weather
from services.search_service import web_search
from services.scheduler_service import schedule_reminder
from datetime import datetime, timedelta
import json
import re
import logging

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    try:
        user_message = request.json.get('message', '').strip()
        if not user_message:
            return jsonify({'error': 'Message cannot be empty'}), 400
        
        # Determine message type and process accordingly
        response_data = process_message(user_message)
        
        # Save to database
        chat_message = ChatMessage(
            message=user_message,
            response=response_data['response'],
            message_type=response_data.get('type', 'chat')
        )
        db.session.add(chat_message)
        db.session.commit()
        
        return jsonify(response_data)
    
    except Exception as e:
        logging.error(f"Chat error: {str(e)}")
        return jsonify({'error': 'Sorry, I encountered an error processing your request. Please try again.'}), 500

def process_message(message):
    """Process the user message and determine the appropriate response"""
    message_lower = message.lower()
    
    # Todo commands
    if any(keyword in message_lower for keyword in ['add task', 'todo', 'to do', 'add to list']):
        return handle_todo_add(message)
    elif any(keyword in message_lower for keyword in ['complete task', 'finish task', 'done with']):
        return handle_todo_complete(message)
    elif any(keyword in message_lower for keyword in ['show tasks', 'list tasks', 'my tasks', 'todo list']):
        return handle_todo_list()
    
    # Weather commands
    elif any(keyword in message_lower for keyword in ['weather', 'temperature', 'forecast']):
        return handle_weather(message)
    
    # Search commands
    elif any(keyword in message_lower for keyword in ['search for', 'look up', 'find information']):
        return handle_search(message)
    
    # Reminder commands
    elif any(keyword in message_lower for keyword in ['remind me', 'set reminder', 'schedule reminder']):
        return handle_reminder(message)
    
    # Time/date commands
    elif any(keyword in message_lower for keyword in ['what time', 'current time', 'time is it']):
        return handle_time()
    
    # Default to AI chat
    else:
        return handle_ai_chat(message)

def handle_todo_add(message):
    """Extract task from message and add to todo list"""
    # Extract task from various formats
    task = extract_task_from_message(message)
    if task:
        todo_item = TodoItem(task=task)
        db.session.add(todo_item)
        db.session.commit()
        return {
            'response': f"✅ Added '{task}' to your todo list!",
            'type': 'todo',
            'action': 'add'
        }
    else:
        return {
            'response': "I couldn't identify the task to add. Please try something like 'Add task: buy groceries'",
            'type': 'todo',
            'action': 'error'
        }

def handle_todo_complete(message):
    """Mark a task as completed"""
    # Simple implementation - complete the most recent uncompleted task
    # or extract task name from message
    task_name = extract_task_from_message(message)
    if task_name:
        todo_item = TodoItem.query.filter(
            TodoItem.task.ilike(f'%{task_name}%'),
            TodoItem.completed == False
        ).first()
    else:
        todo_item = TodoItem.query.filter_by(completed=False).first()
    
    if todo_item:
        todo_item.completed = True
        todo_item.completed_at = datetime.utcnow()
        db.session.commit()
        return {
            'response': f"✅ Marked '{todo_item.task}' as completed!",
            'type': 'todo',
            'action': 'complete'
        }
    else:
        return {
            'response': "No matching uncompleted tasks found.",
            'type': 'todo',
            'action': 'error'
        }

def handle_todo_list():
    """Show current todo list"""
    todos = TodoItem.query.filter_by(completed=False).order_by(TodoItem.created_at.desc()).all()
    if todos:
        task_list = "\n".join([f"• {todo.task}" for todo in todos])
        return {
            'response': f"📋 Your current tasks:\n{task_list}",
            'type': 'todo',
            'action': 'list',
            'tasks': [{'id': todo.id, 'task': todo.task} for todo in todos]
        }
    else:
        return {
            'response': "🎉 Your todo list is empty! Great job staying on top of things.",
            'type': 'todo',
            'action': 'list',
            'tasks': []
        }

def handle_weather(message):
    """Get weather information"""
    try:
        # Extract location from message or use default
        location = extract_location_from_message(message) or "current location"
        weather_data = get_weather(location)
        
        if weather_data:
            return {
                'response': weather_data,
                'type': 'weather'
            }
        else:
            return {
                'response': "Sorry, I couldn't get the weather information right now. Please try again later.",
                'type': 'weather'
            }
    except Exception as e:
        logging.error(f"Weather error: {str(e)}")
        return {
            'response': "Sorry, I encountered an error getting the weather. Please try again.",
            'type': 'weather'
        }

def handle_search(message):
    """Perform web search"""
    try:
        query = extract_search_query(message)
        if query:
            search_results = web_search(query)
            return {
                'response': search_results,
                'type': 'search'
            }
        else:
            return {
                'response': "Please specify what you'd like me to search for.",
                'type': 'search'
            }
    except Exception as e:
        logging.error(f"Search error: {str(e)}")
        return {
            'response': "Sorry, I couldn't perform the search right now. Please try again later.",
            'type': 'search'
        }

def handle_reminder(message):
    """Set a reminder"""
    try:
        reminder_data = extract_reminder_from_message(message)
        if reminder_data:
            reminder = Reminder(
                title=reminder_data['title'],
                description=reminder_data.get('description', ''),
                reminder_time=reminder_data['time']
            )
            db.session.add(reminder)
            db.session.commit()
            
            # Schedule the reminder
            schedule_reminder(reminder)
            
            return {
                'response': f"⏰ Reminder set: '{reminder_data['title']}' at {reminder_data['time'].strftime('%Y-%m-%d %H:%M')}",
                'type': 'reminder'
            }
        else:
            return {
                'response': "I couldn't understand the reminder details. Try something like 'Remind me to call mom at 3 PM tomorrow'",
                'type': 'reminder'
            }
    except Exception as e:
        logging.error(f"Reminder error: {str(e)}")
        return {
            'response': "Sorry, I couldn't set the reminder. Please try again.",
            'type': 'reminder'
        }

def handle_time():
    """Get current time"""
    current_time = datetime.now()
    return {
        'response': f"🕐 Current time: {current_time.strftime('%I:%M %p on %A, %B %d, %Y')}",
        'type': 'time'
    }

def handle_ai_chat(message):
    """Use OpenAI for general chat"""
    try:
        ai_response = get_ai_response(message)
        return {
            'response': ai_response,
            'type': 'chat'
        }
    except Exception as e:
        logging.error(f"AI chat error: {str(e)}")
        return {
            'response': "I'm having trouble connecting to my AI brain right now. Could you try again in a moment?",
            'type': 'chat'
        }

# Helper functions for message parsing
def extract_task_from_message(message):
    """Extract task description from message"""
    patterns = [
        r'add task:?\s*(.+)',
        r'todo:?\s*(.+)',
        r'add to list:?\s*(.+)',
        r'complete task:?\s*(.+)',
        r'finish task:?\s*(.+)',
        r'done with:?\s*(.+)'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, message, re.IGNORECASE)
        if match:
            return match.group(1).strip()
    return None

def extract_location_from_message(message):
    """Extract location from weather message"""
    patterns = [
        r'weather in (.+)',
        r'weather for (.+)',
        r'temperature in (.+)'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, message, re.IGNORECASE)
        if match:
            return match.group(1).strip()
    return None

def extract_search_query(message):
    """Extract search query from message"""
    patterns = [
        r'search for (.+)',
        r'look up (.+)',
        r'find information about (.+)'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, message, re.IGNORECASE)
        if match:
            return match.group(1).strip()
    return None

def extract_reminder_from_message(message):
    """Extract reminder details from message"""
    # Basic implementation - would need more sophisticated parsing for production
    patterns = [
        r'remind me to (.+?) at (.+)',
        r'set reminder for (.+?) at (.+)',
        r'remind me (.+?) in (\d+) (hour|hours|minute|minutes)'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, message, re.IGNORECASE)
        if match:
            title = match.group(1).strip()
            time_str = match.group(2).strip()
            
            # Parse time - basic implementation
            reminder_time = parse_time_string(time_str)
            if reminder_time:
                return {
                    'title': title,
                    'time': reminder_time
                }
    return None

def parse_time_string(time_str):
    """Parse time string into datetime object"""
    try:
        # Handle relative times
        if 'hour' in time_str:
            hours = int(re.search(r'(\d+)', time_str).group(1))
            return datetime.now() + timedelta(hours=hours)
        elif 'minute' in time_str:
            minutes = int(re.search(r'(\d+)', time_str).group(1))
            return datetime.now() + timedelta(minutes=minutes)
        elif 'tomorrow' in time_str.lower():
            # Simple tomorrow parsing
            return datetime.now().replace(hour=9, minute=0, second=0, microsecond=0) + timedelta(days=1)
        else:
            # Try to parse as time
            return datetime.strptime(time_str, '%I:%M %p')
    except:
        return None

@app.route('/api/todos', methods=['GET'])
def get_todos():
    """API endpoint to get all todos"""
    todos = TodoItem.query.order_by(TodoItem.created_at.desc()).all()
    return jsonify([{
        'id': todo.id,
        'task': todo.task,
        'completed': todo.completed,
        'created_at': todo.created_at.isoformat(),
        'completed_at': todo.completed_at.isoformat() if todo.completed_at else None
    } for todo in todos])

@app.route('/api/todos/<int:todo_id>/toggle', methods=['POST'])
def toggle_todo(todo_id):
    """API endpoint to toggle todo completion"""
    todo = TodoItem.query.get_or_404(todo_id)
    todo.completed = not todo.completed
    todo.completed_at = datetime.utcnow() if todo.completed else None
    db.session.commit()
    return jsonify({'success': True})

@app.route('/api/todos/<int:todo_id>', methods=['DELETE'])
def delete_todo(todo_id):
    """API endpoint to delete todo"""
    todo = TodoItem.query.get_or_404(todo_id)
    db.session.delete(todo)
    db.session.commit()
    return jsonify({'success': True})
