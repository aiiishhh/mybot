# Contributing to myBot

Thank you for your interest in contributing to myBot! This document provides guidelines and information for contributors.

## Getting Started

### Prerequisites
- Python 3.11 or higher
- Git
- OpenAI API key for testing

### Setting Up Development Environment

1. Fork the repository on GitHub
2. Clone your fork locally:
```bash
git clone https://github.com/YOUR_USERNAME/myBot.git
cd myBot
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up environment variables:
```bash
export OPENAI_API_KEY="your_test_api_key"
export DATABASE_URL="sqlite:///test.db"
```

5. Run the application:
```bash
python main.py
```

## Development Guidelines

### Code Structure

- **Services**: Put business logic in `services/` directory
- **Routes**: HTTP handlers in `routes.py`
- **Models**: Database models in `models.py`
- **Frontend**: HTML templates in `templates/`, static assets in `static/`

### Code Style

- Follow PEP 8 for Python code
- Use meaningful variable and function names
- Add docstrings for all functions
- Keep functions small and focused
- Use type hints where appropriate

### Adding New Features

1. **Service Layer**: Create new service modules in `services/`
2. **Database**: Add models to `models.py` if needed
3. **Routes**: Add API endpoints in `routes.py`
4. **Frontend**: Update templates and JavaScript as needed
5. **Message Processing**: Update `process_message()` function for new commands

### Example: Adding a New Service

```python
# services/new_service.py
import os
import logging

API_KEY = os.environ.get("NEW_SERVICE_API_KEY")

def new_service_function(query):
    """Description of what this function does"""
    if not API_KEY:
        return "API key required for this service"
    
    try:
        # Service implementation
        return result
    except Exception as e:
        logging.error(f"New service error: {str(e)}")
        return "Error message for users"
```

## Testing

### Manual Testing
- Test all chat commands
- Verify error handling
- Check mobile responsiveness
- Test with missing API keys

### Test Commands
```bash
# Test chat functionality
curl -X POST http://localhost:5000/chat -H "Content-Type: application/json" -d '{"message": "hello"}'

# Test task management
curl -X POST http://localhost:5000/chat -H "Content-Type: application/json" -d '{"message": "add task: test task"}'
```

## Submitting Changes

### Pull Request Process

1. Create a feature branch:
```bash
git checkout -b feature/your-feature-name
```

2. Make your changes with clear commit messages:
```bash
git commit -m "Add: new weather forecast feature"
```

3. Push to your fork:
```bash
git push origin feature/your-feature-name
```

4. Create a pull request on GitHub

### Pull Request Guidelines

- **Title**: Clear, descriptive title
- **Description**: Explain what changes were made and why
- **Testing**: Describe how you tested the changes
- **Screenshots**: Include UI changes if applicable

### Commit Message Format

Use clear, descriptive commit messages:
- `Add: new feature description`
- `Fix: bug description`
- `Update: what was updated`
- `Remove: what was removed`

## Feature Ideas

Looking for contribution ideas? Here are some suggestions:

### High Priority
- Email notification system for reminders
- Voice input/output support
- Calendar integration
- File upload and analysis
- Multi-language support

### Medium Priority
- Custom themes
- Chat export functionality
- Advanced search filters
- Integration with productivity tools
- Mobile app companion

### Low Priority
- Plugin system
- Advanced scheduling options
- Chat history search
- Custom commands
- Analytics dashboard

## Reporting Issues

### Bug Reports
When reporting bugs, include:
- Steps to reproduce
- Expected behavior
- Actual behavior
- Environment details (OS, Python version)
- Error messages or logs

### Feature Requests
For feature requests, include:
- Clear description of the feature
- Use case or problem it solves
- Suggested implementation approach
- Any relevant examples or mockups

## Documentation

### Updating Documentation
- Update README.md for user-facing changes
- Update docstrings for code changes
- Add comments for complex logic
- Update API documentation if applicable

### Code Comments
```python
def complex_function(param1, param2):
    """
    Brief description of what the function does.
    
    Args:
        param1 (type): Description of param1
        param2 (type): Description of param2
    
    Returns:
        type: Description of return value
    """
    # Explain complex logic here
    result = complex_logic(param1, param2)
    return result
```

## Environment Variables

Document any new environment variables in:
- README.md
- This contributing guide
- Code comments

Format:
```python
# Required for feature X functionality
NEW_API_KEY = os.environ.get("NEW_API_KEY")
```

## Release Process

1. Version updates follow semantic versioning
2. Update CHANGELOG.md with new features and fixes
3. Test thoroughly in development environment
4. Create release notes for significant updates

## Getting Help

- Check existing issues on GitHub
- Review the documentation
- Ask questions in discussions
- Join the community chat (if available)

## License

By contributing to myBot, you agree that your contributions will be licensed under the MIT License.

## Acknowledgments

- Thank you to all contributors
- Special thanks to the open source community
- Built with Flask, OpenAI, and other amazing tools