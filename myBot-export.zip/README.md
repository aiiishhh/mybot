# myBot - Personal AI Assistant

A Flask-based personal AI assistant with chat interface, featuring OpenAI GPT-4o integration, task management, weather updates, web search, and reminder capabilities.

## Features

- **Intelligent Chat**: Powered by OpenAI GPT-4o for natural conversations
- **Task Management**: Add, complete, and manage your to-do list
- **Weather Updates**: Get current weather information for any location
- **Web Search**: Search the internet and get formatted results
- **Reminders**: Set and schedule reminders with natural language
- **Modern UI**: Bootstrap-based dark theme with mobile-friendly design

## Quick Start

### Prerequisites

- Python 3.11 or higher
- OpenAI API key
- OpenWeatherMap API key (optional, for weather features)
- SerpAPI key (optional, for web search features)

### Installation

1. Clone the repository:
```bash
git clone <your-repo-url>
cd myBot
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up environment variables:
```bash
export OPENAI_API_KEY="your_openai_api_key"
export OPENWEATHER_API_KEY="your_openweather_api_key"  # Optional
export SERPAPI_API_KEY="your_serpapi_key"  # Optional
export DATABASE_URL="your_database_url"  # Optional, defaults to SQLite
export SESSION_SECRET="your_session_secret"
```

4. Run the application:
```bash
python main.py
```

5. Open your browser and go to `http://localhost:5000`

## Usage Examples

### Chat Commands

- **General conversation**: "Hello, how are you?"
- **Task management**: 
  - "Add task: buy groceries"
  - "Show my tasks"
  - "Complete task: buy groceries"
- **Weather**: "What's the weather like in Paris?"
- **Search**: "Search for Python tutorials"
- **Reminders**: "Remind me to call mom at 3 PM tomorrow"
- **Time**: "What time is it?"

## Project Structure

```
myBot/
├── app.py              # Flask application setup
├── main.py             # Application entry point
├── models.py           # Database models
├── routes.py           # API routes and handlers
├── services/           # Service modules
│   ├── openai_service.py
│   ├── weather_service.py
│   ├── search_service.py
│   └── scheduler_service.py
├── templates/          # HTML templates
│   └── index.html
├── static/             # Static assets
│   ├── css/
│   └── js/
└── requirements.txt    # Python dependencies
```

## Configuration

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `OPENAI_API_KEY` | Yes | OpenAI API key for chat functionality |
| `OPENWEATHER_API_KEY` | No | OpenWeatherMap API key for weather |
| `SERPAPI_API_KEY` | No | SerpAPI key for web search |
| `DATABASE_URL` | No | Database connection string (defaults to SQLite) |
| `SESSION_SECRET` | No | Flask session secret key |

### API Keys Setup

1. **OpenAI API Key**: Get from [OpenAI Platform](https://platform.openai.com/)
2. **OpenWeatherMap API Key**: Get from [OpenWeatherMap](https://openweathermap.org/api)
3. **SerpAPI Key**: Get from [SerpAPI](https://serpapi.com/)

## Database

The application uses SQLAlchemy ORM with three main models:
- **TodoItem**: Task management
- **ChatMessage**: Conversation history
- **Reminder**: Scheduled notifications

By default, it uses SQLite for development. For production, set `DATABASE_URL` to your PostgreSQL connection string.

## Features in Detail

### Task Management
- Natural language task addition
- Task completion tracking
- Task listing and management
- Persistent storage

### Weather Service
- Current weather for any location
- Temperature in both Celsius and Fahrenheit
- Weather conditions and additional details
- Graceful fallback when API key is missing

### Reminder System
- Natural language time parsing
- Background job scheduling
- Automatic cleanup of old reminders
- Support for relative and absolute times

### Search Integration
- Web search with formatted results
- News search capabilities
- Quick answer extraction
- Link preservation and formatting

## Development

### Local Development

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set up environment variables in a `.env` file
3. Run in development mode:
```bash
python main.py
```

### Adding New Features

1. Create service modules in `services/` directory
2. Add route handlers in `routes.py`
3. Update message processing logic
4. Add corresponding UI elements if needed

## Deployment

The application is designed to work with various deployment platforms:

- **Replit**: Already configured with proper workflows
- **Heroku**: Add `Procfile` with `web: gunicorn main:app`
- **Railway**: Works out of the box
- **Docker**: Add Dockerfile for containerization

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Troubleshooting

### Common Issues

1. **OpenAI API Error 429**: Check your API quota and billing
2. **Weather API 401**: Verify your OpenWeatherMap API key
3. **Database connection errors**: Check your DATABASE_URL
4. **Missing features**: Ensure all required API keys are set

### Logs

The application uses Python logging. Check console output for detailed error messages and debugging information.

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review the logs for error details
3. Ensure all API keys are properly configured
4. Open an issue with detailed error information