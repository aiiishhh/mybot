from app import db
from datetime import datetime
from sqlalchemy import Text, DateTime, Boolean, Integer, String

class TodoItem(db.Model):
    id = db.Column(Integer, primary_key=True)
    task = db.Column(Text, nullable=False)
    completed = db.Column(Boolean, default=False)
    created_at = db.Column(DateTime, default=datetime.utcnow)
    completed_at = db.Column(DateTime, nullable=True)

class ChatMessage(db.Model):
    id = db.Column(Integer, primary_key=True)
    message = db.Column(Text, nullable=False)
    response = db.Column(Text, nullable=False)
    timestamp = db.Column(DateTime, default=datetime.utcnow)
    message_type = db.Column(String(50), default='chat')  # chat, todo, weather, search, reminder

class Reminder(db.Model):
    id = db.Column(Integer, primary_key=True)
    title = db.Column(String(255), nullable=False)
    description = db.Column(Text)
    reminder_time = db.Column(DateTime, nullable=False)
    completed = db.Column(Boolean, default=False)
    created_at = db.Column(DateTime, default=datetime.utcnow)
